import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/page/login'
import Home from '@/components/page/home'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/login'
    },
    {
      path: '/home',
      component: Home
    },
    {
      path: '/login',
      component: Login
    }
  ]
})
