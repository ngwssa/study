<template>
  <div id="login">
    <h1>PAX IOT System</h1>
    <Form ref="form" :model="form" :rules="rules">
      <Form-item prop="username">
        <Input type="text" v-model="form.username" placeholder="Username">
          <Icon type="ios-person-outline" slot="prepend"></Icon>
        </Input>
      </Form-item>
      <Form-item prop="password">
        <Input type="password" v-model="form.password" placeholder="Password">
          <Icon type="ios-locked-outline" slot="prepend"></Icon>
        </Input>
      </Form-item>
      <Form-item>
        <Button type="primary" @click="handleSubmit('form')">登&nbsp;录</Button>
      </Form-item>
    </Form>
    <Copyright></Copyright>
  </div>
</template>

<script>
  import Copyright from '../common/copyright'
  export default {
    data () {
      return {
        form: {
          username: '',
          password: ''
        },
        rules: {
          username: [
            { required: true, message: '请填写用户名', trigger: 'blur' }
          ],
          password: [
            { required: true, message: '请填写密码', trigger: 'blur' },
            { type: 'string', min: 6, message: '密码长度不能小于6位', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      handleSubmit (name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            // this.$Message.success('提交成功!')
            sessionStorage.setItem('username', this.form.username)
            this.$router.push('/home')
          } else {
            // this.$Message.error('表单验证失败!')
          }
        })
      }
    },
    components: { Copyright }
  }
</script>

<style lang="less">
  #login {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .ivu-form {
      margin-top: 20px;
      padding: 10px;
      width: 300px;
    }
  }
</style>
