<template>
	<div class="copyright">
	  2011-2017 &copy; IOT
	</div>
</template>

<style lang="less" scoped>
  .copyright {
    text-align: center;
    width: 100%;
    padding: 10px 0 20px;
    color: #9ea7b4;
    position: absolute;
    bottom: 0;
    z-index: 2;
    /* align-self: flex-end; */
  }
</style>
