console.log('aaaaaaa')
let n = 0

module.exports = (x) => console.log(n++, '-----' + x)
